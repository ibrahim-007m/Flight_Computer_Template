#include "bno055.h"
#include "main.h"

extern I2C_HandleTypeDef hi2c1;

void bno055_writeData(uint8_t reg, uint8_t data)
{
    HAL_I2C_Mem_Write(&hi2c1, BNO055_I2C_ADDR << 1,
                      reg, I2C_MEMADD_SIZE_8BIT,
                      &data, 1, HAL_MAX_DELAY);
}

void bno055_readData(uint8_t reg, uint8_t *buffer, uint8_t length)
{
    HAL_I2C_Mem_Read(&hi2c1, BNO055_I2C_ADDR << 1,
                     reg, I2C_MEMADD_SIZE_8BIT,
                     buffer, length, HAL_MAX_DELAY);
}

void bno055_delay(int time)
{
    HAL_Delay(time);
}
